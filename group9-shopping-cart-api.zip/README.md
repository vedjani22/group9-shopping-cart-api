# Group 9 Shopping Cart API

## Project Description
Smart Student Marketplace is a full-stack web application plan where students can buy and sell used items such as textbooks, calculators, laptops, and school supplies.

## Technology
- Frontend: HTML, CSS, JavaScript
- Backend: TypeScript + Express
- Database: MySQL

## Why MySQL?
MySQL was selected because the project has structured data such as users, products, categories, cart items, and orders. MySQL supports table relationships and works well with MySQL Workbench for ERD design.

## How to Run

Install dependencies:

```bash
npm install
```

Run development server:

```bash
npm run dev
```

Open website:

```text
http://localhost:3000
```

API test:

```text
http://localhost:3000/api
http://localhost:3000/products
http://localhost:3000/juicereport
http://localhost:3000/products/id_juice/101
```

## Project Structure

```text
public/     HTML, CSS, JavaScript frontend
src/        TypeScript + Express backend
docs/       Database design, API plan, team responsibilities
sql/        MySQL schema file
diagrams/   ERD reference
wireframes/ Wireframe reference files
```

## Team Responsibilities
- Student 1: Database Designer
- Student 2: Backend Planner
- Student 3: Frontend Designer
