async function loadApiStatus() {
  const response = await fetch('/api');
  const data = await response.json();
  document.getElementById('api-status').textContent = JSON.stringify(data, null, 2);
}

async function loadProducts() {
  const response = await fetch('/products');
  const products = await response.json();
  const table = document.getElementById('product-table');
  table.innerHTML = '';

  products.forEach((product) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${product.id}</td>
      <td>${product.name}</td>
      <td>${product.category}</td>
      <td>$${product.price}</td>
      <td>${product.status}</td>
    `;
    table.appendChild(row);
  });
}

async function addProduct(event) {
  event.preventDefault();

  const product = {
    name: document.getElementById('name').value,
    category: document.getElementById('category').value,
    price: document.getElementById('price').value,
    description: document.getElementById('description').value
  };

  const response = await fetch('/products', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(product)
  });

  const data = await response.json();
  document.getElementById('result').textContent = JSON.stringify(data, null, 2);
}

async function updateProduct(event) {
  event.preventDefault();

  const id = document.getElementById('edit-id').value;
  const product = {
    name: document.getElementById('edit-name').value,
    category: document.getElementById('edit-category').value,
    price: document.getElementById('edit-price').value,
    description: document.getElementById('edit-description').value
  };

  const response = await fetch(`/products/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(product)
  });

  const data = await response.json();
  document.getElementById('edit-result').textContent = JSON.stringify(data, null, 2);
}
